package com.gesturepsw;

import org.leanandroid.R;

import android.app.Activity;
import android.os.Bundle;

public class GesturePswActivity extends Activity{

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.gesturepswactivity);
	}
}
