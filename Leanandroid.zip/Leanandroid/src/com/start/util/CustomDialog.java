package com.start.util;

import android.app.Dialog;
import android.content.Context;

public class CustomDialog extends Dialog{

	public CustomDialog(Context context) {
		super(context);
	}
	@Override
	public void show() {
		super.show();
	}
	@Override
	public void dismiss() {
		super.dismiss();
	}
}
