package com.start.vo;

public class Coach {
	private String name;
	private String sex;
	public String getName() {
		return name;
	}
	public Coach setName(String name) {
		this.name = name;
		return this;
	}
	public String getSex() {
		return sex;
	}
	public Coach setSex(String sex) {
		this.sex = sex;
		return this;
	}
	
}
