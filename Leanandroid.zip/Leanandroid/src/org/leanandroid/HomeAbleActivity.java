package org.leanandroid;

import android.app.Activity;
import android.os.Bundle;

public class HomeAbleActivity extends Activity{

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}
	
}
