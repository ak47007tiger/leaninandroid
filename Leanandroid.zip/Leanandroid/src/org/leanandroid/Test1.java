package org.leanandroid;

import android.test.AndroidTestCase;

public class Test1 extends AndroidTestCase {
	public void test1() throws NullPointerException{
		int a = 1;
	}
}
