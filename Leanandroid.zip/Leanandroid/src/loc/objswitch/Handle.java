package loc.objswitch;

public interface Handle {
	Object handle(Object input);
}
