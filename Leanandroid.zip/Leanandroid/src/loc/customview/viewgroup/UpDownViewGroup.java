package loc.customview.viewgroup;

import android.content.Context;
import android.util.AttributeSet;
import android.view.ViewGroup;

public class UpDownViewGroup extends ViewGroup{

	public UpDownViewGroup(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	@Override
	protected void onLayout(boolean arg0, int l, int t, int r, int b) {
		
	}

}
