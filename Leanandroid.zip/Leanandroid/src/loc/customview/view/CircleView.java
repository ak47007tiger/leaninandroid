package loc.customview.view;

public class CircleView {

}
